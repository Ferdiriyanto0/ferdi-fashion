import React, { useState, useEffect, useRef } from "react";
import { ShoppingBag, Menu, X, Instagram, MessageCircle, Star, ArrowUpRight, ChevronDown, Plus, Minus, Search } from "lucide-react";

// ============ DATA ============
const CATEGORIES = ["Semua", "Kaos", "Kemeja", "Jaket", "Celana"];

const PRODUCTS = [
  { id: 1, name: "Kaos Polos Combed 30s", cat: "Kaos", price: 95000, oldPrice: 130000, tag: "Diskon", img: "https://images.unsplash.com/photo-1521572163474-6864f9cf17ab?w=600&q=80" },
  { id: 2, name: "Kemeja Flanel Kotak", cat: "Kemeja", price: 175000, oldPrice: 220000, tag: "Diskon", img: "https://images.unsplash.com/photo-1602810318383-e386cc2a3ccf?w=600&q=80" },
  { id: 3, name: "Jaket Denim Washed", cat: "Jaket", price: 285000, oldPrice: 350000, tag: "Diskon", img: "https://images.unsplash.com/photo-1601333144130-8cbb312386b6?w=600&q=80" },
  { id: 4, name: "Celana Chino Slim Fit", cat: "Celana", price: 175000, oldPrice: 215000, tag: "Diskon", img: "https://images.unsplash.com/photo-1473966968600-fa801b869a1a?w=600&q=80" },
  { id: 5, name: "Kaos Oversize Streetwear", cat: "Kaos", price: 115000, oldPrice: null, tag: "Best Seller", img: "https://images.unsplash.com/photo-1576566588028-4147f3842f27?w=600&q=80" },
  { id: 6, name: "Kemeja Linen Lengan Panjang", cat: "Kemeja", price: 189000, oldPrice: null, tag: "Baru", img: "https://images.unsplash.com/photo-1564859228273-274232fdb516?w=600&q=80" },
  { id: 7, name: "Jaket Bomber Hitam", cat: "Jaket", price: 325000, oldPrice: null, tag: "Baru", img: "https://images.unsplash.com/photo-1551028719-00167b16eac5?w=600&q=80" },
  { id: 8, name: "Celana Cargo Jogger", cat: "Celana", price: 195000, oldPrice: null, tag: "Best Seller", img: "https://images.unsplash.com/photo-1517438476312-10d79c077509?w=600&q=80" },
];

const TESTIMONIALS = [
  { name: "Rizky A.", city: "Bandung", text: "Bahan kaosnya tebal, gak nerawang. Udah cuci berkali-kali masih bagus bentuknya.", rating: 5 },
  { name: "Dimas P.", city: "Surabaya", text: "Jaket denimnya pas banget di badan, packingnya juga rapi. Bakal order lagi.", rating: 5 },
  { name: "Fajar W.", city: "Jakarta", text: "Respon admin cepat, barang sampai lebih cepat dari estimasi. Mantap FERDI.", rating: 4 },
];

const fmt = (n) => "Rp" + n.toLocaleString("id-ID");

// ============ HANGTAG SIGNATURE ELEMENT ============
function HangTag({ className = "", rotate = -6, children }) {
  return (
    <div
      className={`relative inline-flex items-center gap-2 select-none ${className}`}
      style={{ transform: `rotate(${rotate}deg)` }}
    >
      <svg width="14" height="14" viewBox="0 0 24 24" className="opacity-70 flex-shrink-0">
        <circle cx="12" cy="12" r="9" fill="none" stroke="currentColor" strokeWidth="1.5" />
        <circle cx="12" cy="12" r="2.5" fill="currentColor" />
      </svg>
      <span className="font-tag tracking-wide whitespace-nowrap">{children}</span>
    </div>
  );
}

// ============ NAVBAR ============
function Navbar({ cartCount, onCartClick }) {
  const [open, setOpen] = useState(false);
  const [scrolled, setScrolled] = useState(false);

  useEffect(() => {
    const onScroll = () => setScrolled(window.scrollY > 20);
    window.addEventListener("scroll", onScroll);
    return () => window.removeEventListener("scroll", onScroll);
  }, []);

  const links = [
    { label: "Produk", href: "#produk" },
    { label: "Tentang", href: "#tentang" },
    { label: "Ulasan", href: "#ulasan" },
    { label: "Kontak", href: "#kontak" },
  ];

  return (
    <header
      className={`fixed top-0 left-0 right-0 z-50 transition-all duration-300 ${
        scrolled ? "bg-[#F5F3EF]/95 backdrop-blur-md shadow-[0_1px_0_rgba(26,26,26,0.08)]" : "bg-transparent"
      }`}
    >
      <div className="max-w-6xl mx-auto px-5 md:px-8 h-16 md:h-20 flex items-center justify-between">
        <a href="#top" className="font-display text-xl md:text-2xl tracking-tight text-ink">
          FERDI<span className="text-brick">.</span>
        </a>

        <nav className="hidden md:flex items-center gap-9">
          {links.map((l) => (
            <a
              key={l.label}
              href={l.href}
              className="font-tag text-[13px] tracking-wider uppercase text-ink/70 hover:text-ink transition-colors relative group"
            >
              {l.label}
              <span className="absolute -bottom-1.5 left-0 w-0 h-[1.5px] bg-brick transition-all group-hover:w-full" />
            </a>
          ))}
        </nav>

        <div className="flex items-center gap-4">
          <button
            onClick={onCartClick}
            aria-label="Buka keranjang"
            className="relative p-2 -m-2 text-ink hover:text-brick transition-colors"
          >
            <ShoppingBag size={21} strokeWidth={1.75} />
            {cartCount > 0 && (
              <span className="absolute -top-0.5 -right-0.5 bg-brick text-white text-[10px] font-bold rounded-full w-4 h-4 flex items-center justify-center">
                {cartCount}
              </span>
            )}
          </button>
          <button
            className="md:hidden p-2 -m-2 text-ink"
            onClick={() => setOpen((v) => !v)}
            aria-label="Buka menu"
          >
            {open ? <X size={22} /> : <Menu size={22} />}
          </button>
        </div>
      </div>

      {open && (
        <div className="md:hidden bg-[#F5F3EF] border-t border-ink/10 px-5 py-4 flex flex-col gap-4">
          {links.map((l) => (
            <a
              key={l.label}
              href={l.href}
              onClick={() => setOpen(false)}
              className="font-tag text-sm uppercase tracking-wider text-ink/80"
            >
              {l.label}
            </a>
          ))}
        </div>
      )}
    </header>
  );
}

// ============ HERO ============
function Hero() {
  return (
    <section id="top" className="relative pt-28 md:pt-36 pb-16 md:pb-24 overflow-hidden">
      {/* background texture */}
      <div
        className="absolute inset-0 opacity-[0.035] pointer-events-none"
        style={{
          backgroundImage:
            "repeating-linear-gradient(45deg, #1A1A1A 0, #1A1A1A 1px, transparent 1px, transparent 14px)",
        }}
      />

      <div className="max-w-6xl mx-auto px-5 md:px-8 relative">
        <div className="grid md:grid-cols-[1.1fr_0.9fr] gap-10 md:gap-8 items-center">
          {/* Left: copy */}
          <div className="relative">
            <HangTag rotate={-4} className="text-ink/60 text-[11px] mb-6">
              KOLEKSI TERBARU — 2026
            </HangTag>

            <h1 className="font-display leading-[0.92] text-ink">
              <span className="block text-[15vw] md:text-[5.2rem] tracking-[-0.02em]">PAKAIAN</span>
              <span className="block text-[15vw] md:text-[5.2rem] tracking-[-0.02em] -mt-1 md:-mt-3">
                BUAT <span className="text-brick">GERAK,</span>
              </span>
              <span className="block text-[15vw] md:text-[5.2rem] tracking-[-0.02em] -mt-1 md:-mt-3">BUKAN PAJANGAN.</span>
            </h1>

            <p className="font-body text-ink/65 text-base md:text-lg mt-6 max-w-md leading-relaxed">
              FERDI FASHION bikin pakaian pria buat dipakai tiap hari — nyaman dari pagi
              nongkrong sampe malem jalan-jalan. Simpel, kuat, harga masuk akal.
            </p>

            <div className="flex flex-wrap items-center gap-4 mt-8">
              <a
                href="#produk"
                className="inline-flex items-center gap-2 bg-ink text-[#F5F3EF] px-7 py-3.5 font-tag text-[13px] uppercase tracking-wider hover:bg-brick transition-colors"
              >
                Belanja Sekarang <ArrowUpRight size={15} />
              </a>
              <a
                href="#tentang"
                className="inline-flex items-center gap-2 text-ink/70 hover:text-ink font-tag text-[13px] uppercase tracking-wider underline underline-offset-4"
              >
                Kenalan dulu sama brand-nya
              </a>
            </div>

            <div className="flex items-center gap-6 mt-10 pt-8 border-t border-ink/10">
              <Stat n="500+" label="Pelanggan Puas" />
              <Stat n="4.8/5" label="Rating Toko" />
              <Stat n="3-5 Hari" label="Pengiriman" />
            </div>
          </div>

          {/* Right: image with tag */}
          <div className="relative">
            <div className="relative aspect-[4/5] overflow-hidden bg-ink/5">
              <img
                src="https://images.unsplash.com/photo-1488161628813-04466f872be2?w=800&q=80"
                alt="Model memakai pakaian casual FERDI FASHION"
                className="w-full h-full object-cover"
                loading="eager"
              />
              <div className="absolute inset-0 ring-1 ring-inset ring-ink/10" />
            </div>

            {/* floating hangtag card */}
            <div className="absolute -bottom-5 -left-5 md:-left-8 bg-[#F5F3EF] border border-ink/15 px-4 py-3 shadow-[4px_4px_0_rgba(26,26,26,0.08)] rotate-[-3deg]">
              <p className="font-tag text-[10px] uppercase tracking-widest text-ink/50">Mulai dari</p>
              <p className="font-display text-xl text-ink">Rp65.000</p>
            </div>
          </div>
        </div>
      </div>
    </section>
  );
}

function Stat({ n, label }) {
  return (
    <div>
      <p className="font-display text-xl md:text-2xl text-ink">{n}</p>
      <p className="font-tag text-[10px] uppercase tracking-widest text-ink/45 mt-0.5">{label}</p>
    </div>
  );
}

// ============ MARQUEE STRIP ============
function MarqueeStrip() {
  const items = ["BAHAN PREMIUM", "GRATIS ONGKIR MIN. 200K", "COD TERSEDIA", "TUKAR SIZE 7 HARI"];
  return (
    <div className="bg-ink text-[#F5F3EF] py-3 overflow-hidden border-y border-ink">
      <div className="flex whitespace-nowrap animate-marquee">
        {[...items, ...items, ...items].map((it, i) => (
          <span key={i} className="font-tag text-xs uppercase tracking-[0.15em] mx-6 flex items-center gap-6">
            {it} <span className="text-brick">●</span>
          </span>
        ))}
      </div>
    </div>
  );
}

// ============ PRODUCT CARD ============
function ProductCard({ p, onAdd }) {
  return (
    <div className="group relative">
      <div className="relative aspect-[3/4] overflow-hidden bg-ink/5">
        <img
          src={p.img}
          alt={p.name}
          className="w-full h-full object-cover transition-transform duration-500 group-hover:scale-[1.04]"
          loading="lazy"
        />
        {p.tag && (
          <span
            className={`absolute top-3 left-3 font-tag text-[10px] uppercase tracking-wider px-2.5 py-1 ${
              p.tag === "Diskon" ? "bg-brick text-white" : "bg-[#F5F3EF] text-ink border border-ink/15"
            }`}
          >
            {p.tag}
          </span>
        )}
        <button
          onClick={() => onAdd(p)}
          className="absolute bottom-0 left-0 right-0 bg-ink text-[#F5F3EF] font-tag text-[12px] uppercase tracking-wider py-3 flex items-center justify-center gap-2 translate-y-full group-hover:translate-y-0 transition-transform duration-300"
        >
          <Plus size={14} /> Tambah ke Keranjang
        </button>
      </div>
      <div className="mt-3 flex items-start justify-between gap-2">
        <div>
          <p className="font-tag text-[10px] uppercase tracking-widest text-ink/40">{p.cat}</p>
          <p className="font-body text-ink text-[15px] mt-0.5">{p.name}</p>
        </div>
      </div>
      <div className="flex items-center gap-2 mt-1">
        <p className="font-display text-base text-ink">{fmt(p.price)}</p>
        {p.oldPrice && <p className="font-body text-sm text-ink/35 line-through">{fmt(p.oldPrice)}</p>}
      </div>
    </div>
  );
}

// ============ PRODUCTS SECTION ============
function ProductsSection({ onAdd }) {
  const [active, setActive] = useState("Semua");
  const [query, setQuery] = useState("");

  const filtered = PRODUCTS.filter(
    (p) =>
      (active === "Semua" || p.cat === active) &&
      p.name.toLowerCase().includes(query.toLowerCase())
  );

  return (
    <section id="produk" className="py-20 md:py-28 max-w-6xl mx-auto px-5 md:px-8">
      <div className="flex flex-col md:flex-row md:items-end justify-between gap-6 mb-10">
        <div>
          <HangTag rotate={-3} className="text-ink/50 text-[11px] mb-3">
            KATALOG
          </HangTag>
          <h2 className="font-display text-3xl md:text-4xl text-ink leading-tight">
            Pilih Gaya Lo<br />Hari Ini
          </h2>
        </div>

        <div className="relative w-full md:w-64">
          <Search size={16} className="absolute left-3 top-1/2 -translate-y-1/2 text-ink/40" />
          <input
            type="text"
            value={query}
            onChange={(e) => setQuery(e.target.value)}
            placeholder="Cari produk..."
            className="w-full bg-transparent border border-ink/20 pl-9 pr-3 py-2.5 font-body text-sm text-ink placeholder:text-ink/40 focus:outline-none focus:border-ink/60 transition-colors"
          />
        </div>
      </div>

      <div className="flex flex-wrap gap-2 mb-10">
        {CATEGORIES.map((c) => (
          <button
            key={c}
            onClick={() => setActive(c)}
            className={`font-tag text-[12px] uppercase tracking-wider px-4 py-2 border transition-colors ${
              active === c
                ? "bg-ink text-[#F5F3EF] border-ink"
                : "border-ink/20 text-ink/60 hover:border-ink/50 hover:text-ink"
            }`}
          >
            {c}
          </button>
        ))}
      </div>

      {filtered.length === 0 ? (
        <div className="text-center py-16 border border-dashed border-ink/20">
          <p className="font-tag text-sm uppercase tracking-wider text-ink/50">
            Produk tidak ditemukan. Coba kata lain atau pilih kategori berbeda.
          </p>
        </div>
      ) : (
        <div className="grid grid-cols-2 md:grid-cols-3 gap-x-5 gap-y-10">
          {filtered.map((p) => (
            <ProductCard key={p.id} p={p} onAdd={onAdd} />
          ))}
        </div>
      )}
    </section>
  );
}

// ============ ABOUT ============
function About() {
  return (
    <section id="tentang" className="bg-ink text-[#F5F3EF] py-20 md:py-28">
      <div className="max-w-6xl mx-auto px-5 md:px-8 grid md:grid-cols-2 gap-12 items-center">
        <div className="relative order-2 md:order-1">
          <div className="aspect-square overflow-hidden">
            <img
              src="https://images.unsplash.com/photo-1556905055-8f358a7a47b2?w=700&q=80"
              alt="Proses produksi pakaian FERDI FASHION"
              className="w-full h-full object-cover"
              loading="lazy"
            />
          </div>
          <div className="absolute -top-4 -right-4 md:-right-6 bg-brick text-white px-4 py-3 rotate-[3deg]">
            <p className="font-display text-lg">Sejak 2021</p>
          </div>
        </div>

        <div className="order-1 md:order-2">
          <HangTag rotate={-3} className="text-[#F5F3EF]/50 text-[11px] mb-4">
            CERITA KAMI
          </HangTag>
          <h2 className="font-display text-3xl md:text-4xl leading-tight mb-5">
            Dari Tongkrongan,<br />Buat Tongkrongan.
          </h2>
          <p className="font-body text-[#F5F3EF]/70 leading-relaxed mb-4">
            FERDI FASHION lahir dari hal sederhana: susah cari kaos yang nyaman tapi
            nggak mahal-mahal. Jadi kita bikin sendiri — bahan dipilih langsung, dijahit rapi,
            dan harganya tetap masuk akal buat dipakai tiap hari.
          </p>
          <p className="font-body text-[#F5F3EF]/70 leading-relaxed mb-8">
            Sekarang kami sudah melayani ratusan pelanggan dari Sabang sampai Merauke,
            tapi caranya tetap sama: dengar apa yang lo butuhin, kirim yang terbaik.
          </p>

          <div className="grid grid-cols-3 gap-4 pt-6 border-t border-[#F5F3EF]/15">
            <div>
              <p className="font-display text-2xl text-brick">100%</p>
              <p className="font-tag text-[10px] uppercase tracking-widest text-[#F5F3EF]/50 mt-1">Cotton Pilihan</p>
            </div>
            <div>
              <p className="font-display text-2xl text-brick">34</p>
              <p className="font-tag text-[10px] uppercase tracking-widest text-[#F5F3EF]/50 mt-1">Kota Terjangkau</p>
            </div>
            <div>
              <p className="font-display text-2xl text-brick">5+</p>
              <p className="font-tag text-[10px] uppercase tracking-widest text-[#F5F3EF]/50 mt-1">Tahun Berdiri</p>
            </div>
          </div>
        </div>
      </div>
    </section>
  );
}

// ============ TESTIMONIALS ============
function Testimonials() {
  return (
    <section id="ulasan" className="py-20 md:py-28 max-w-6xl mx-auto px-5 md:px-8">
      <div className="text-center mb-12">
        <HangTag rotate={2} className="text-ink/50 text-[11px] mb-3 justify-center">
          KATA MEREKA
        </HangTag>
        <h2 className="font-display text-3xl md:text-4xl text-ink">Bukan Kita yang Ngomong</h2>
      </div>

      <div className="grid md:grid-cols-3 gap-6">
        {TESTIMONIALS.map((t, i) => (
          <div key={i} className="border border-ink/12 p-6 bg-[#F5F3EF] hover:border-ink/30 transition-colors">
            <div className="flex gap-0.5 mb-3">
              {Array.from({ length: 5 }).map((_, idx) => (
                <Star
                  key={idx}
                  size={14}
                  className={idx < t.rating ? "fill-brick text-brick" : "fill-ink/15 text-ink/15"}
                />
              ))}
            </div>
            <p className="font-body text-ink/75 text-[15px] leading-relaxed mb-5">"{t.text}"</p>
            <p className="font-tag text-[11px] uppercase tracking-wider text-ink/45">
              {t.name} — {t.city}
            </p>
          </div>
        ))}
      </div>
    </section>
  );
}

// ============ FAQ ============
function FAQ() {
  const faqs = [
    { q: "Berapa lama pengiriman?", a: "Estimasi 3-5 hari kerja untuk wilayah Jawa, dan 5-7 hari untuk luar Jawa, tergantung jasa ekspedisi yang dipilih." },
    { q: "Apakah bisa tukar ukuran?", a: "Bisa, selama produk belum dipakai dan masih dalam kondisi asli, kami terima tukar ukuran dalam 7 hari setelah barang diterima." },
    { q: "Metode pembayaran apa yang tersedia?", a: "Transfer bank, e-wallet, dan COD (Bayar di Tempat) untuk wilayah yang didukung kurir kami." },
    { q: "Apakah ada size chart?", a: "Ada, setiap produk dilengkapi tabel ukuran detail di halaman produk. Kalau masih ragu, admin kami siap bantu lewat WhatsApp." },
  ];
  const [openIdx, setOpenIdx] = useState(0);

  return (
    <section className="py-20 md:py-28 max-w-3xl mx-auto px-5 md:px-8">
      <h2 className="font-display text-3xl md:text-4xl text-ink mb-10 text-center">Pertanyaan Umum</h2>
      <div className="divide-y divide-ink/12 border-t border-b border-ink/12">
        {faqs.map((f, i) => (
          <div key={i}>
            <button
              onClick={() => setOpenIdx(openIdx === i ? -1 : i)}
              className="w-full flex items-center justify-between py-5 text-left"
            >
              <span className="font-body text-ink text-[15px] md:text-base pr-4">{f.q}</span>
              {openIdx === i ? <Minus size={16} className="text-ink/50 flex-shrink-0" /> : <Plus size={16} className="text-ink/50 flex-shrink-0" />}
            </button>
            {openIdx === i && (
              <p className="font-body text-ink/60 text-[14px] leading-relaxed pb-5 pr-8">{f.a}</p>
            )}
          </div>
        ))}
      </div>
    </section>
  );
}

// ============ CONTACT / CTA ============
function Contact() {
  return (
    <section id="kontak" className="py-20 md:py-28 max-w-6xl mx-auto px-5 md:px-8">
      <div className="bg-ink text-[#F5F3EF] px-6 md:px-16 py-14 md:py-20 text-center relative overflow-hidden">
        <HangTag rotate={-2} className="text-[#F5F3EF]/50 text-[11px] mb-5 justify-center">
          MASIH BINGUNG PILIH?
        </HangTag>
        <h2 className="font-display text-3xl md:text-5xl leading-tight mb-6">
          Chat Admin,<br className="md:hidden" /> Dibantu Pilihin.
        </h2>
        <p className="font-body text-[#F5F3EF]/65 max-w-md mx-auto mb-8">
          Tim FERDI FASHION siap bantu lo nentuin ukuran dan model yang pas, langsung lewat WhatsApp.
        </p>
        <a
          href="https://wa.me/6285219248205"
          target="_blank"
          rel="noopener noreferrer"
          className="inline-flex items-center gap-2 bg-[#F5F3EF] text-ink px-7 py-3.5 font-tag text-[13px] uppercase tracking-wider hover:bg-brick hover:text-white transition-colors"
        >
          <MessageCircle size={16} /> Chat via WhatsApp
        </a>
      </div>
    </section>
  );
}

// ============ FOOTER ============
function Footer() {
  return (
    <footer className="border-t border-ink/12 py-12 max-w-6xl mx-auto px-5 md:px-8">
      <div className="flex flex-col md:flex-row justify-between gap-8">
        <div className="max-w-xs">
          <p className="font-display text-xl text-ink mb-3">
            FERDI<span className="text-brick">.</span>
          </p>
          <p className="font-body text-sm text-ink/55 leading-relaxed">
            Pakaian pria untuk gerak, bukan pajangan. Dikirim dari Bandung ke seluruh Indonesia.
          </p>
        </div>

        <div className="flex gap-12">
          <div>
            <p className="font-tag text-[11px] uppercase tracking-widest text-ink/40 mb-3">Navigasi</p>
            <ul className="font-body text-sm text-ink/65 space-y-2">
              <li><a href="#produk" className="hover:text-ink">Produk</a></li>
              <li><a href="#tentang" className="hover:text-ink">Tentang</a></li>
              <li><a href="#ulasan" className="hover:text-ink">Ulasan</a></li>
            </ul>
          </div>
          <div>
            <p className="font-tag text-[11px] uppercase tracking-widest text-ink/40 mb-3">Hubungi</p>
            <ul className="font-body text-sm text-ink/65 space-y-2">
              <li className="flex items-center gap-1.5"><Instagram size={14} /> @ferdifashion.id</li>
              <li className="flex items-center gap-1.5"><MessageCircle size={14} /> 0852-1924-8205</li>
            </ul>
          </div>
        </div>
      </div>

      <p className="font-body text-xs text-ink/35 mt-10 pt-6 border-t border-ink/10">
        © 2026 FERDI FASHION. Semua hak cipta dilindungi.
      </p>
    </footer>
  );
}

// ============ CART DRAWER ============
function CartDrawer({ open, items, onClose, onRemove }) {
  const total = items.reduce((sum, i) => sum + i.price, 0);

  return (
    <>
      <div
        className={`fixed inset-0 bg-ink/40 z-[60] transition-opacity ${
          open ? "opacity-100 pointer-events-auto" : "opacity-0 pointer-events-none"
        }`}
        onClick={onClose}
      />
      <div
        className={`fixed top-0 right-0 h-full w-full max-w-sm bg-[#F5F3EF] z-[70] shadow-2xl transition-transform duration-300 flex flex-col ${
          open ? "translate-x-0" : "translate-x-full"
        }`}
      >
        <div className="flex items-center justify-between px-6 py-5 border-b border-ink/12">
          <p className="font-display text-lg text-ink">Keranjang ({items.length})</p>
          <button onClick={onClose} aria-label="Tutup keranjang" className="text-ink/60 hover:text-ink">
            <X size={20} />
          </button>
        </div>

        <div className="flex-1 overflow-y-auto px-6 py-4">
          {items.length === 0 ? (
            <p className="font-body text-sm text-ink/45 text-center mt-10">
              Belum ada barang. Yuk pilih produk favorit lo dulu.
            </p>
          ) : (
            <ul className="space-y-4">
              {items.map((it, idx) => (
                <li key={idx} className="flex gap-3 items-center">
                  <img src={it.img} alt={it.name} className="w-16 h-20 object-cover flex-shrink-0" />
                  <div className="flex-1">
                    <p className="font-body text-sm text-ink">{it.name}</p>
                    <p className="font-display text-sm text-ink mt-0.5">{fmt(it.price)}</p>
                  </div>
                  <button
                    onClick={() => onRemove(idx)}
                    className="text-ink/40 hover:text-brick font-tag text-[11px] uppercase tracking-wider"
                  >
                    Hapus
                  </button>
                </li>
              ))}
            </ul>
          )}
        </div>

        {items.length > 0 && (
          <div className="px-6 py-5 border-t border-ink/12">
            <div className="flex justify-between mb-4">
              <span className="font-tag text-xs uppercase tracking-widest text-ink/50">Total</span>
              <span className="font-display text-lg text-ink">{fmt(total)}</span>
            </div>
            <a
              href={`https://wa.me/6285219248205?text=${encodeURIComponent(
                "Halo FERDI FASHION, saya mau pesan:\n" +
                  items.map((i) => `- ${i.name} (${fmt(i.price)})`).join("\n") +
                  `\nTotal: ${fmt(total)}`
              )}`}
              target="_blank"
              rel="noopener noreferrer"
              className="block text-center bg-ink text-[#F5F3EF] py-3.5 font-tag text-[13px] uppercase tracking-wider hover:bg-brick transition-colors"
            >
              Checkout via WhatsApp
            </a>
          </div>
        )}
      </div>
    </>
  );
}

// ============ TOAST ============
function Toast({ message, show }) {
  return (
    <div
      className={`fixed bottom-6 left-1/2 -translate-x-1/2 z-[80] bg-ink text-[#F5F3EF] px-5 py-3 font-tag text-xs uppercase tracking-wider transition-all duration-300 ${
        show ? "opacity-100 translate-y-0" : "opacity-0 translate-y-4 pointer-events-none"
      }`}
    >
      {message}
    </div>
  );
}

// ============ ROOT APP ============
export default function App() {
  const [cart, setCart] = useState([]);
  const [cartOpen, setCartOpen] = useState(false);
  const [toast, setToast] = useState({ show: false, message: "" });
  const toastTimer = useRef(null);

  const handleAdd = (product) => {
    setCart((c) => [...c, product]);
    setToast({ show: true, message: `${product.name} ditambahkan` });
    clearTimeout(toastTimer.current);
    toastTimer.current = setTimeout(() => setToast((t) => ({ ...t, show: false })), 2200);
  };

  const handleRemove = (idx) => {
    setCart((c) => c.filter((_, i) => i !== idx));
  };

  return (
    <div className="min-h-screen bg-[#F5F3EF] text-ink font-body antialiased">
      <style>{`
        :root {
          --ink: #1A1A1A;
          --brick: #B5482F;
        }
        .text-ink { color: var(--ink); }
        .bg-ink { background-color: var(--ink); }
        .border-ink { border-color: var(--ink); }
        .text-brick { color: var(--brick); }
        .bg-brick { background-color: var(--brick); }
        .fill-brick { fill: var(--brick); }
        .font-display {
          font-family: 'Anton', 'Arial Narrow', sans-serif;
          font-weight: 400;
        }
        .font-tag {
          font-family: 'Space Grotesk', 'Helvetica Neue', sans-serif;
          font-weight: 500;
        }
        .font-body {
          font-family: 'Inter', 'Helvetica Neue', sans-serif;
        }
        @keyframes marquee {
          0% { transform: translateX(0); }
          100% { transform: translateX(-33.333%); }
        }
        .animate-marquee {
          animation: marquee 18s linear infinite;
        }
        @media (prefers-reduced-motion: reduce) {
          .animate-marquee { animation: none; }
          * { transition-duration: 0.01ms !important; }
        }
        a:focus-visible, button:focus-visible, input:focus-visible {
          outline: 2px solid var(--brick);
          outline-offset: 2px;
        }
      `}</style>

      <Navbar cartCount={cart.length} onCartClick={() => setCartOpen(true)} />
      <Hero />
      <MarqueeStrip />
      <ProductsSection onAdd={handleAdd} />
      <About />
      <Testimonials />
      <FAQ />
      <Contact />
      <Footer />

      <CartDrawer open={cartOpen} items={cart} onClose={() => setCartOpen(false)} onRemove={handleRemove} />
      <Toast show={toast.show} message={toast.message} />
    </div>
  );
}
